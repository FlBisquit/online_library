"""Tests for the library app."""
import base64
import csv
import io
import json
from datetime import datetime, timedelta, timezone as dt_timezone
from unittest.mock import patch

from django.contrib.auth.models import Group
from django.db import connection, transaction
from django.test import TransactionTestCase, override_settings
from django.test.utils import CaptureQueriesContext
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from library import models, services
from library import roles


def _ensure_group(name):
    group, _created = Group.objects.get_or_create(name=name)
    return group


@override_settings(DEFAULT_THROTTLE_RATES={"token": "1000/min"})
class LibraryTestCase(APITestCase):
    def setUp(self):
        self.librarian_group = _ensure_group(roles.LIBRARIAN_ROLE)
        self.reader_group = _ensure_group(roles.READER_ROLE)
        self.admin_group = _ensure_group(roles.ADMIN_ROLE)

        self.librarian = models.Reader.objects.create_user(
            email="librarian@test.local",
            password="LibrarianPass123",
            full_name="Библиотекарь",
        )
        self.librarian.groups.add(self.librarian_group)

        self.admin = models.Reader.objects.create_user(
            email="admin@test.local",
            password="AdminPass123",
            full_name="Администратор",
        )
        self.admin.groups.add(self.admin_group)

        self.reader = models.Reader.objects.create_user(
            email="reader@test.local",
            password="ReaderPass123",
            full_name="Читатель Читалов",
        )
        self.reader.groups.add(self.reader_group)

        self.other_reader = models.Reader.objects.create_user(
            email="reader2@test.local",
            password="ReaderPass123",
            full_name="Второй Читатель",
        )
        self.other_reader.groups.add(self.reader_group)

        self.book = models.Book.objects.create(
            title="Тестовая книга",
            isbn="978-5-000-000-00-0",
            publication_year=2020,
            publisher="Издательство",
        )
        self.copy = models.BookCopy.objects.create(
            book=self.book,
            inventory_number="INV-1",
        )

    # ---------- Аутентификация и JWT ----------

    def test_token_obtain_pair_success(self):
        response = self.client.post(
            "/api/token/",
            {"email": "reader@test.local", "password": "ReaderPass123"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("access", response.data)
        self.assertIn("refresh", response.data)

    def test_token_refresh_and_blacklist(self):
        token_response = self.client.post(
            "/api/token/",
            {"email": "reader@test.local", "password": "ReaderPass123"},
            format="json",
        )
        refresh = token_response.data["refresh"]
        refresh_response = self.client.post(
            "/api/token/refresh/",
            {"refresh": refresh},
            format="json",
        )
        self.assertEqual(refresh_response.status_code, status.HTTP_200_OK)
        new_refresh = refresh_response.data.get("refresh", refresh)

        blacklist_response = self.client.post(
            "/api/token/blacklist/",
            {"refresh": new_refresh},
            format="json",
        )
        self.assertEqual(blacklist_response.status_code, status.HTTP_200_OK)

        refreshed_after_blacklist = self.client.post(
            "/api/token/refresh/",
            {"refresh": new_refresh},
            format="json",
        )
        self.assertEqual(refreshed_after_blacklist.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_access_token_lifetime_is_15_minutes(self):
        response = self.client.post(
            "/api/token/",
            {"email": "reader@test.local", "password": "ReaderPass123"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        access_token = response.data["access"]
        payload = json.loads(
            base64.urlsafe_b64decode(
                access_token.split(".")[1] + "=" * (-len(access_token.split(".")[1]) % 4)
            )
        )
        self.assertIn("exp", payload)
        self.assertIn("iat", payload)
        self.assertEqual(payload["exp"] - payload["iat"], 900)

    def test_blocked_reader_cannot_get_token(self):
        self.reader.status = models.Reader.Status.BLOCKED
        self.reader.save(update_fields=["status"])
        response = self.client.post(
            "/api/token/",
            {"email": "reader@test.local", "password": "ReaderPass123"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_blocked_reader_access_token_rejected(self):
        token_response = self.client.post(
            "/api/token/",
            {"email": "reader@test.local", "password": "ReaderPass123"},
            format="json",
        )
        access = token_response.data["access"]
        self.reader.status = models.Reader.Status.BLOCKED
        self.reader.save(update_fields=["status"])
        response = self.client.get("/api/auth/me/", HTTP_AUTHORIZATION=f"Bearer {access}")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_auth_me_returns_roles(self):
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/auth/me/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["email"], "reader@test.local")
        self.assertIn("reader", response.data["groups"])

    def test_logout_with_invalid_refresh_token(self):
        response = self.client.post(
            "/api/token/blacklist/",
            {"refresh": "invalid-refresh-token"},
            format="json",
        )
        self.assertIn(response.status_code, [status.HTTP_400_BAD_REQUEST, status.HTTP_401_UNAUTHORIZED])

    def test_access_token_required_for_protected_endpoint(self):
        response = self.client.get(f"/api/readers/{self.reader.id}/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)


class BookCatalogTests(LibraryTestCase):
    def test_create_book_as_librarian(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/books/",
            {
                "title": "Новая книга",
                "description": "Описание",
                "isbn": "978-5-222-222-22-2",
                "publication_year": 2022,
                "publisher": "Издательство",
                "authors": [],
                "genres": [],
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(models.Book.objects.count(), 2)

    def test_create_book_duplicate_isbn_returns_409(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/books/",
            {"title": "Дубль", "isbn": "978-5-000-000-00-0", "publication_year": 2020},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

    def test_book_detail(self):
        self.client.force_authenticate(self.reader)
        response = self.client.get(f"/api/books/{self.book.id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "Тестовая книга")

    def test_book_list_search_and_pagination(self):
        models.Book.objects.create(title="Другая книга", isbn="978-5-333-333-33-3")
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/books/", {"search": "Тестовая"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]), 1)
        self.assertEqual(response.data["count"], 1)

    def test_book_list_requires_no_auth(self):
        response = self.client.get("/api/books/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class BookCopyTests(LibraryTestCase):
    def test_add_copy_and_list_copies(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            f"/api/books/{self.book.id}/copies/",
            {"inventory_number": "INV-2", "status": "AVAILABLE"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        response = self.client.get(f"/api/books/{self.book.id}/copies/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]), 2)

    def test_add_copy_duplicate_inventory_number_returns_409(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            f"/api/books/{self.book.id}/copies/",
            {"inventory_number": "INV-1", "status": "AVAILABLE"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)


class CatalogManagementTests(LibraryTestCase):
    """Управление каталогом: права, CRUD, переходы и ограничения удаления."""

    def catalog_write_cases(self):
        return [
            ("post", "/api/books/", {"title": "Новая", "isbn": "978-5-777-000-00-1"}),
            ("patch", f"/api/books/{self.book.id}/", {"title": "Переименовано"}),
            ("delete", f"/api/books/{self.book.id}/", None),
            (
                "post",
                f"/api/books/{self.book.id}/copies/",
                {"inventory_number": "CAT-NEW-1"},
            ),
            ("patch", f"/api/copies/{self.copy.id}/", {"status": "LOST"}),
            ("delete", f"/api/copies/{self.copy.id}/", None),
            ("post", "/api/authors/", {"full_name": "Автор"}),
            ("patch", "/api/authors/1/", {"full_name": "Автор 2"}),
            ("delete", "/api/authors/1/", None),
            ("post", "/api/genres/", {"name": "Жанр"}),
            ("patch", "/api/genres/1/", {"name": "Жанр 2"}),
            ("delete", "/api/genres/1/", None),
        ]

    def _request(self, method, path, data):
        if data is None:
            return getattr(self.client, method)(path)
        return getattr(self.client, method)(path, data, format="json")

    def test_reader_cannot_write_catalog(self):
        self.client.force_authenticate(self.reader)
        for method, path, data in self.catalog_write_cases():
            with self.subTest(method=method, path=path):
                self.assertEqual(self._request(method, path, data).status_code, 403)

    def test_librarian_and_admin_can_write_catalog(self):
        for index, user in enumerate([self.librarian, self.admin], start=1):
            self.client.force_authenticate(user)
            book = self.client.post(
                "/api/books/",
                {"title": f"Книга {index}", "isbn": f"978-5-777-000-01-{index}"},
                format="json",
            )
            self.assertEqual(book.status_code, 201)

            patch = self.client.patch(
                f"/api/books/{book.data['id']}/", {"publisher": "Издатель"}, format="json"
            )
            self.assertEqual(patch.status_code, 200)

            author = self.client.post(
                "/api/authors/", {"full_name": f"Автор {index}"}, format="json"
            )
            self.assertEqual(author.status_code, 201)
            genre = self.client.post(
                "/api/genres/", {"name": f"Жанр {index}"}, format="json"
            )
            self.assertEqual(genre.status_code, 201)

            copy = self.client.post(
                f"/api/books/{book.data['id']}/copies/",
                {"inventory_number": f"CAT-{index}"},
                format="json",
            )
            self.assertEqual(copy.status_code, 201)
            updated = self.client.patch(
                f"/api/copies/{copy.data['id']}/", {"status": "LOST"}, format="json"
            )
            self.assertEqual(updated.status_code, 200)

            self.assertEqual(
                self.client.delete(f"/api/copies/{copy.data['id']}/").status_code, 204
            )
            self.assertEqual(
                self.client.delete(f"/api/books/{book.data['id']}/").status_code, 204
            )
            self.assertEqual(
                self.client.delete(f"/api/authors/{author.data['id']}/").status_code, 204
            )
            self.assertEqual(
                self.client.delete(f"/api/genres/{genre.data['id']}/").status_code, 204
            )

    def test_catalog_read_is_available_to_everyone(self):
        paths = [
            "/api/books/",
            f"/api/books/{self.book.id}/",
            f"/api/books/{self.book.id}/copies/",
            "/api/authors/",
            "/api/genres/",
        ]
        for user in [None, self.reader, self.librarian, self.admin]:
            self.client.force_authenticate(user)
            for path in paths:
                with self.subTest(user=user, path=path):
                    self.assertEqual(self.client.get(path).status_code, 200)

    def test_delete_book_with_issue_returns_409(self):
        models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
        )
        self.client.force_authenticate(self.admin)
        response = self.client.delete(f"/api/books/{self.book.id}/")
        self.assertEqual(response.status_code, 409)
        self.assertTrue(models.Book.objects.filter(pk=self.book.id).exists())

    def test_delete_book_with_live_reservation_returns_409(self):
        models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            queue_date=timezone.now(),
            active_slot=1,
        )
        self.client.force_authenticate(self.admin)
        response = self.client.delete(f"/api/books/{self.book.id}/")
        self.assertEqual(response.status_code, 409)
        self.assertTrue(models.Book.objects.filter(pk=self.book.id).exists())

    def test_copy_patch_uses_transitions_and_logs(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.patch(
            f"/api/copies/{self.copy.id}/", {"status": "LOST"}, format="json"
        )
        self.assertEqual(response.status_code, 200)
        self.copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.LOST)
        log = models.ActionLog.objects.get(entity_type="BookCopy", entity_id=self.copy.id)
        self.assertEqual(log.old_status, models.BookCopy.Status.AVAILABLE)
        self.assertEqual(log.new_status, models.BookCopy.Status.LOST)

        forbidden = self.client.patch(
            f"/api/copies/{self.copy.id}/", {"status": "ISSUED"}, format="json"
        )
        self.assertEqual(forbidden.status_code, 409)
        self.copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.LOST)

    def test_manual_available_from_issued_or_reserved_returns_409(self):
        for locked_status in (
            models.BookCopy.Status.ISSUED,
            models.BookCopy.Status.RESERVED,
        ):
            with self.subTest(status=locked_status):
                self.copy.status = locked_status
                self.copy.save(update_fields=["status"])
                issue = models.Issue.objects.create(
                    reader=self.reader,
                    copy=self.copy,
                    issued_at=timezone.now(),
                    due_at=timezone.now() + timedelta(days=14),
                )
                self.client.force_authenticate(self.librarian)
                response = self.client.patch(
                    f"/api/copies/{self.copy.id}/", {"status": "AVAILABLE"}, format="json"
                )
                self.assertEqual(response.status_code, 409)
                self.copy.refresh_from_db()
                self.assertEqual(self.copy.status, locked_status)
                issue.refresh_from_db()
                self.assertEqual(issue.status, models.Issue.Status.ISSUED)

    def test_delete_copy_with_issue_returns_409(self):
        models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
        )
        self.client.force_authenticate(self.admin)
        response = self.client.delete(f"/api/copies/{self.copy.id}/")
        self.assertEqual(response.status_code, 409)
        self.assertTrue(models.BookCopy.objects.filter(pk=self.copy.id).exists())

    def test_delete_copy_with_live_reservation_returns_409(self):
        reservation = models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            copy=self.copy,
            status=models.Reservation.Status.ACTIVE,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(days=1),
            active_slot=1,
        )
        self.client.force_authenticate(self.admin)
        response = self.client.delete(f"/api/copies/{self.copy.id}/")
        self.assertEqual(response.status_code, 409)
        self.assertTrue(models.BookCopy.objects.filter(pk=self.copy.id).exists())
        reservation.refresh_from_db()
        self.assertEqual(reservation.copy_id, self.copy.id)

    def test_limit_query_param_controls_page_size(self):
        for index in range(3):
            models.Book.objects.create(
                title=f"Доп. книга {index}", isbn=f"978-5-888-000-00-{index}"
            )
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/books/", {"limit": 2})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["count"], 4)
        self.assertEqual(len(response.data["results"]), 2)


class UserManagementTests(LibraryTestCase):
    """Управление пользователями доступно только администраторам."""

    def _make_user(self, email, role=roles.READER_ROLE, status=None):
        reader = models.Reader.objects.create_user(
            email=email,
            password="ReaderPass123",
            full_name=email.split("@")[0],
            status=status or models.Reader.Status.ACTIVE,
        )
        reader.groups.add(_ensure_group(role))
        return reader

    def _patch(self, target, data, actor=None):
        self.client.force_authenticate(actor or self.admin)
        return self.client.patch(f"/api/users/{target.id}/", data, format="json")

    def test_role_matrix_for_users(self):
        for user in [self.reader, self.librarian]:
            self.client.force_authenticate(user)
            with self.subTest(user=user.email):
                self.assertEqual(self.client.get("/api/users/").status_code, 403)
                self.assertEqual(
                    self.client.post(
                        "/api/users/",
                        {
                            "email": f"new-{user.id}@test.local",
                            "password": "StrongPass123!",
                            "full_name": "Новый",
                            "role": "librarian",
                        },
                        format="json",
                    ).status_code,
                    403,
                )
                self.assertEqual(
                    self.client.patch(
                        f"/api/users/{self.reader.id}/", {"status": "BLOCKED"}, format="json"
                    ).status_code,
                    403,
                )
        self.client.force_authenticate(self.admin)
        self.assertEqual(self.client.get("/api/users/").status_code, 200)

    def test_admin_can_create_staff_with_explicit_role(self):
        self.client.force_authenticate(self.admin)
        response = self.client.post(
            "/api/users/",
            {
                "email": "staff@test.local",
                "password": "StrongPass123!",
                "full_name": "Сотрудник",
                "role": "librarian",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        created = models.Reader.objects.get(email="staff@test.local")
        self.assertTrue(created.groups.filter(name=roles.LIBRARIAN_ROLE).exists())

        invalid = self.client.post(
            "/api/users/",
            {
                "email": "reader-new@test.local",
                "password": "StrongPass123!",
                "full_name": "Читатель",
                "role": "reader",
            },
            format="json",
        )
        self.assertEqual(invalid.status_code, 400)

    def test_search_filters_and_limit(self):
        self._make_user("anna@test.local")
        self._make_user("boris@test.local", role=roles.LIBRARIAN_ROLE)
        self._make_user("victor@test.local", status=models.Reader.Status.BLOCKED)
        self.client.force_authenticate(self.admin)

        response = self.client.get("/api/users/", {"search": "anna"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual([row["email"] for row in response.data["results"]], ["anna@test.local"])

        response = self.client.get("/api/users/", {"role": roles.LIBRARIAN_ROLE})
        emails = {row["email"] for row in response.data["results"]}
        self.assertIn("boris@test.local", emails)
        self.assertNotIn("anna@test.local", emails)

        response = self.client.get("/api/users/", {"status": models.Reader.Status.BLOCKED})
        self.assertEqual(response.data["count"], 1)

        response = self.client.get("/api/users/", {"limit": 2})
        self.assertEqual(len(response.data["results"]), 2)
        self.assertEqual(response.data["count"], 7)

    def test_role_change_takes_effect_immediately_and_is_logged(self):
        response = self._patch(self.other_reader, {"role": roles.LIBRARIAN_ROLE})
        self.assertEqual(response.status_code, 200)
        self.other_reader.refresh_from_db()
        self.assertTrue(self.other_reader.groups.filter(name=roles.LIBRARIAN_ROLE).exists())
        self.assertFalse(self.other_reader.groups.filter(name=roles.READER_ROLE).exists())

        self.client.force_authenticate(self.other_reader)
        created = self.client.post(
            "/api/books/",
            {"title": "После смены роли", "isbn": "978-5-999-000-00-1"},
            format="json",
        )
        self.assertEqual(created.status_code, 201)

        log = models.ActionLog.objects.filter(
            action="user.role_change", entity_id=self.other_reader.id
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.user, self.admin)
        self.assertEqual(log.details["old_role"], roles.READER_ROLE)
        self.assertEqual(log.details["new_role"], roles.LIBRARIAN_ROLE)

    def test_status_change_validates_and_is_logged(self):
        response = self._patch(self.reader, {"status": models.Reader.Status.BLOCKED})
        self.assertEqual(response.status_code, 200)
        self.reader.refresh_from_db()
        self.assertEqual(self.reader.status, models.Reader.Status.BLOCKED)
        log = models.ActionLog.objects.filter(
            action="user.status_change", entity_id=self.reader.id
        ).first()
        self.assertIsNotNone(log)
        self.assertEqual(log.old_status, models.Reader.Status.ACTIVE)
        self.assertEqual(log.new_status, models.Reader.Status.BLOCKED)

        invalid = self._patch(self.reader, {"status": models.Reader.Status.SUSPENDED})
        self.assertEqual(invalid.status_code, 400)

    def test_cannot_block_or_demote_self(self):
        self.assertEqual(
            self._patch(self.admin, {"status": models.Reader.Status.BLOCKED}).status_code,
            409,
        )
        self.assertEqual(
            self._patch(self.admin, {"role": roles.LIBRARIAN_ROLE}).status_code,
            409,
        )
        self.admin.refresh_from_db()
        self.assertEqual(self.admin.status, models.Reader.Status.ACTIVE)
        self.assertTrue(self.admin.groups.filter(name=roles.ADMIN_ROLE).exists())

    def test_last_admin_cannot_be_demoted_or_blocked(self):
        second = self._make_user("admin2@test.local", role=roles.ADMIN_ROLE)
        self.assertEqual(
            self._patch(second, {"role": roles.LIBRARIAN_ROLE}).status_code, 200
        )
        # Остался один активный администратор — попытка заблокировать его даёт 409.
        self.assertEqual(
            self._patch(self.admin, {"status": models.Reader.Status.BLOCKED}).status_code,
            409,
        )

    def test_duplicate_readers_route_is_removed(self):
        self.client.force_authenticate(self.admin)
        self.assertEqual(self.client.get("/api/readers/").status_code, 404)
        self.assertEqual(
            self.client.get(f"/api/readers/{self.reader.id}/").status_code, 200
        )
        self.assertEqual(
            self.client.get(f"/api/readers/{self.reader.id}/issues/").status_code, 200
        )


class ReaderTests(LibraryTestCase):
    def test_register_reader_success_assigns_reader_group(self):
        response = self.client.post(
            "/api/auth/register/",
            {
                "full_name": "Новый Читатель",
                "email": "newreader@test.local",
                "password": "Str0ngPass!123",
                "phone": "+79990002222",
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        reader = models.Reader.objects.get(email="newreader@test.local")
        self.assertEqual(list(reader.groups.values_list("name", flat=True)), ["reader"])
        self.assertEqual(reader.status, models.Reader.Status.ACTIVE)

    def test_register_reader_creates_missing_reader_group(self):
        Group.objects.filter(name=roles.READER_ROLE).delete()
        response = self.client.post(
            "/api/auth/register/",
            {
                "full_name": "Читатель без группы",
                "email": "fresh@test.local",
                "password": "Str0ngPass!123",
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        reader = models.Reader.objects.get(email="fresh@test.local")
        self.assertEqual(list(reader.groups.values_list("name", flat=True)), ["reader"])

    def test_register_reader_weak_password_returns_400(self):
        response = self.client.post(
            "/api/auth/register/",
            {"full_name": "Слабый Читатель", "email": "weak@test.local", "password": "1"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_register_reader_rejects_groups_and_status(self):
        response = self.client.post(
            "/api/auth/register/",
            {
                "full_name": "Читатель с группой",
                "email": "withgroup@test.local",
                "password": "Str0ngPass!123",
                "groups": ["librarian"],
                "status": "BLOCKED",
                "is_staff": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        reader = models.Reader.objects.get(email="withgroup@test.local")
        self.assertEqual(list(reader.groups.values_list("name", flat=True)), ["reader"])
        self.assertEqual(reader.status, models.Reader.Status.ACTIVE)

    def test_reader_registration_duplicate_email_returns_409(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/auth/register/",
            {"full_name": "Дубль", "email": "reader@test.local", "password": "Str0ngPass!123"},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)


class IssueTests(LibraryTestCase):
    def test_issue_successful(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.ISSUED)
        issue = models.Issue.objects.get()
        self.assertEqual(issue.reader, self.reader)
        self.assertEqual(issue.status, models.Issue.Status.ISSUED)
        self.assertAlmostEqual(
            (issue.due_at - issue.issued_at).total_seconds(),
            14 * 24 * 60 * 60,
            places=0,
        )

    def test_issue_already_issued_copy_returns_409(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.other_reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

    def test_issue_by_reader_forbidden(self):
        self.client.force_authenticate(self.reader)
        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.other_reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_issue_unknown_copy_returns_404(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.reader.id, "copy_id": 99999},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_issue_serializer_returns_nested_book_reader_and_copy(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["book"]["id"], self.book.id)
        self.assertEqual(response.data["book"]["title"], "Тестовая книга")
        self.assertEqual(response.data["reader"]["id"], self.reader.id)
        self.assertEqual(response.data["reader"]["full_name"], "Читатель Читалов")
        self.assertEqual(response.data["copy"]["inventory_number"], "INV-1")

    def test_issue_list_due_overdue_and_search_filters(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now() - timedelta(days=30),
            due_at=timezone.now() - timedelta(days=16),
            status=models.Issue.Status.ISSUED,
        )
        other_copy = models.BookCopy.objects.create(
            book=self.book, inventory_number="INV-2", status=models.BookCopy.Status.ISSUED
        )
        models.Issue.objects.create(
            reader=self.other_reader,
            copy=other_copy,
            issued_at=timezone.now() - timedelta(days=30),
            due_at=timezone.now() - timedelta(days=16),
            status=models.Issue.Status.ISSUED,
        )
        future_copy = models.BookCopy.objects.create(
            book=self.book, inventory_number="INV-3", status=models.BookCopy.Status.ISSUED
        )
        models.Issue.objects.create(
            reader=self.reader,
            copy=future_copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.BookCopy.Status.ISSUED,
        )

        self.client.force_authenticate(self.librarian)
        overdue = self.client.get("/api/issues/", {"due": "overdue"})
        self.assertEqual(overdue.status_code, status.HTTP_200_OK)
        self.assertEqual(len(overdue.data["results"]), 2)

        found = self.client.get("/api/issues/", {"search": "Второй Читатель"})
        self.assertEqual(found.status_code, status.HTTP_200_OK)
        self.assertEqual(len(found.data["results"]), 1)

    def test_return_issue_successful(self):
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        issue.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.RETURNED)
        self.assertIsNotNone(issue.returned_at)
        self.copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.AVAILABLE)

    def test_return_issue_locks_reservation_before_issue(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        reservation = models.Reservation.objects.create(
            reader=self.other_reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            queue_date=timezone.now(),
            active_slot=1,
        )
        with CaptureQueriesContext(connection) as captured:
            services.return_issue(issue.id, user=self.librarian)

        queries = [query["sql"] for query in captured.captured_queries]
        reservation_lock = next(
            index
            for index, sql in enumerate(queries)
            if "library_reservation" in sql and "FOR UPDATE" in sql
        )
        issue_lock = next(
            index
            for index, sql in enumerate(queries)
            if "library_issue" in sql and "FOR UPDATE" in sql
        )
        self.assertLess(reservation_lock, issue_lock)
        reservation.refresh_from_db()
        self.assertEqual(reservation.status, models.Reservation.Status.ACTIVE)

    def test_return_twice_returns_409(self):
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.librarian)
        first = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(first.status_code, status.HTTP_200_OK)
        second = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(second.status_code, status.HTTP_409_CONFLICT)


class WaitingQueueTests(LibraryTestCase):
    def test_reader_joins_queue(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        self.client.force_authenticate(self.reader)
        response = self.client.post(
            f"/api/books/{self.book.id}/queue/",
            {"reader_id": self.reader.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        reservation = models.Reservation.objects.get()
        self.assertEqual(reservation.status, models.Reservation.Status.PENDING)
        self.assertEqual(reservation.active_slot, 1)

    def test_duplicate_queue_entry_returns_409(self):
        reservation = models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(hours=48),
        )
        self.client.force_authenticate(self.reader)
        response = self.client.post(
            f"/api/books/{self.book.id}/queue/",
            {"reader_id": self.reader.id},
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)

    def test_queue_position(self):
        reservation = models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(hours=48),
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.get(f"/api/books/{self.book.id}/queue/{self.reader.id}/position/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["position"], 1)


class ReportsTests(LibraryTestCase):
    """Отчёт по книгам: выдачи, просрочки и отмены за период."""

    @staticmethod
    def _dt(year, month, day, hour=0, minute=0, second=0):
        return datetime(year, month, day, hour, minute, second, tzinfo=dt_timezone.utc)

    def setUp(self):
        super().setUp()
        self.period = {"date_from": "2026-11-01", "date_to": "2026-11-30"}
        self.empty_book = models.Book.objects.create(
            title="Книга без выдач", isbn="978-5-000-000-00-1"
        )
        self.other_book = models.Book.objects.create(
            title="Книга с отменами", isbn="978-5-000-000-00-2"
        )
        self.other_copy = models.BookCopy.objects.create(
            book=self.other_book, inventory_number="INV-REPORT-2"
        )

    def _issue(self, issued_at, status, copy=None):
        return models.Issue.objects.create(
            reader=self.reader,
            copy=copy or self.copy,
            issued_at=issued_at,
            due_at=issued_at + timedelta(days=14),
            status=status,
        )

    def _cancellation(self, book, queue_date, cancelled_at):
        return models.Reservation.objects.create(
            reader=self.reader,
            book=book,
            status=models.Reservation.Status.CANCELLED,
            queue_date=queue_date,
            cancelled_at=cancelled_at,
            active_slot=None,
        )

    def _seed_data(self):
        self._issue(self._dt(2026, 11, 1), models.Issue.Status.OVERDUE)
        self._issue(self._dt(2026, 11, 30, 23, 59, 59), models.Issue.Status.RETURNED)
        self._issue(self._dt(2026, 10, 31, 23, 59), models.Issue.Status.ISSUED)
        self._issue(self._dt(2026, 12, 1), models.Issue.Status.ISSUED)
        # Дата постановки в очередь вне периода, отмена — внутри: считать нужно.
        self._cancellation(
            self.book,
            self._dt(2026, 10, 1),
            self._dt(2026, 11, 15, 12),
        )
        # Дата постановки внутри периода, отмена — вне: в отчёт не попадает.
        self._cancellation(
            self.book,
            self._dt(2026, 11, 5),
            self._dt(2026, 12, 1),
        )
        self._cancellation(
            self.other_book,
            self._dt(2026, 11, 20),
            self._dt(2026, 11, 29, 18),
        )

    def _rows_by_title(self, response):
        return {row["title"]: row for row in response.data}

    def test_report_keeps_books_without_loans_and_aggregates_counts(self):
        self._seed_data()
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/reports/books/", self.period)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        rows = self._rows_by_title(response)

        self.assertEqual(rows["Тестовая книга"]["loans"], 2)
        self.assertEqual(rows["Тестовая книга"]["overdue"], 1)
        self.assertEqual(rows["Тестовая книга"]["cancellations"], 1)

        self.assertEqual(rows["Книга без выдач"]["loans"], 0)
        self.assertEqual(rows["Книга без выдач"]["overdue"], 0)
        self.assertEqual(rows["Книга без выдач"]["cancellations"], 0)

        self.assertEqual(rows["Книга с отменами"]["loans"], 0)
        self.assertEqual(rows["Книга с отменами"]["cancellations"], 1)

    def test_period_is_half_open_at_utc_boundaries(self):
        self._seed_data()
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/reports/books/", self.period)
        rows = self._rows_by_title(response)
        # 2026-11-01 00:00 и 2026-11-30 23:59:59 попали, 31.10 и 01.12 — нет.
        self.assertEqual(rows["Тестовая книга"]["loans"], 2)

    def test_invalid_dates_return_400(self):
        self.client.force_authenticate(self.librarian)
        for params in [
            {"date_from": "not-a-date", "date_to": "2026-11-30"},
            {"date_from": "2026-11-01", "date_to": "2026-99-99"},
            {"date_from": "2026-11-30", "date_to": "2026-11-01"},
            {"date_to": "2026-11-30"},
        ]:
            with self.subTest(params=params):
                response = self.client.get("/api/reports/books/", params)
                self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_reader_is_forbidden(self):
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/reports/books/", self.period)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_query_count_is_constant(self):
        self._seed_data()
        self.client.force_authenticate(self.librarian)
        # Проверка роли + один SQL-запрос с агрегацией по всем книгам.
        with self.assertNumQueries(2):
            response = self.client.get("/api/reports/books/", self.period)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def _parse_csv(self, response):
        self.assertTrue(response.content.startswith(b"\xef\xbb\xbf"))
        return list(csv.reader(io.StringIO(response.content.decode("utf-8-sig"))))

    def test_csv_matches_json_and_has_excel_headers(self):
        self._seed_data()
        self.client.force_authenticate(self.librarian)
        json_response = self.client.get("/api/reports/books/", self.period)
        csv_response = self.client.get("/api/reports/books/export/", self.period)

        self.assertEqual(csv_response.status_code, status.HTTP_200_OK)
        self.assertTrue(csv_response["Content-Type"].startswith("text/csv"))
        self.assertEqual(
            csv_response["Content-Disposition"],
            'attachment; filename="report_2026-11-01_2026-11-30.csv"',
        )
        rows = self._parse_csv(csv_response)
        self.assertEqual(rows[0], ["ID", "Книга", "Выдачи", "Просрочено", "Отмены"])
        expected = [
            [str(row["book_id"]), row["title"], str(row["loans"]), str(row["overdue"]), str(row["cancellations"])]
            for row in json_response.data
        ]
        self.assertEqual(rows[1:], expected)

    def test_csv_escapes_formula_prefixes(self):
        for index, title in enumerate(["=SUM(1+1)", "+CMD", "-CMD", "@SUM"]):
            models.Book.objects.create(title=title, isbn=f"978-5-900-000-00-{index}")
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/reports/books/export/", self.period)
        rows = self._parse_csv(response)
        titles = {row[1]: row for row in rows[1:]}
        for dangerous in ["=SUM(1+1)", "+CMD", "-CMD", "@SUM"]:
            with self.subTest(title=dangerous):
                self.assertIn(f"'{dangerous}", titles)
                self.assertNotIn(dangerous, [row[1] for row in rows[1:]])

    def test_export_reader_is_forbidden(self):
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/reports/books/export/", self.period)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_export_invalid_dates_return_400(self):
        self.client.force_authenticate(self.librarian)
        response = self.client.get(
            "/api/reports/books/export/", {"date_from": "garbage", "date_to": "2026-11-30"}
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_old_report_endpoints_are_removed(self):
        self.client.force_authenticate(self.librarian)
        for path in [
            "/api/reports/issues/",
            "/api/reports/cancellations/",
            "/api/reports/issues/export/",
        ]:
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


class ConcurrentIssueTests(TransactionTestCase):
    """Тест конкурентной выдачи последнего экземпляра (транзакции + select_for_update)."""

    def setUp(self):
        super().setUp()
        self.librarian_group = _ensure_group(roles.LIBRARIAN_ROLE)
        self.reader_group = _ensure_group(roles.READER_ROLE)

        self.librarian = models.Reader.objects.create_user(
            email="librarian@test.local",
            password="LibrarianPass123",
            full_name="Библиотекарь",
        )
        self.librarian.groups.add(self.librarian_group)

        self.reader = models.Reader.objects.create_user(
            email="reader@test.local",
            password="ReaderPass123",
            full_name="Читатель Читалов",
        )
        self.reader.groups.add(self.reader_group)

        self.other_reader = models.Reader.objects.create_user(
            email="reader2@test.local",
            password="ReaderPass123",
            full_name="Второй Читатель",
        )
        self.other_reader.groups.add(self.reader_group)

        self.book = models.Book.objects.create(
            title="Тестовая книга",
            isbn="978-5-000-000-00-0",
            publication_year=2020,
            publisher="Издательство",
        )
        self.copy = models.BookCopy.objects.create(
            book=self.book,
            inventory_number="INV-1",
        )

    def test_concurrent_issue_of_last_copy(self):
        from threading import Thread

        from rest_framework.test import APIClient

        results = []

        def worker(librarian, reader):
            client = APIClient()
            client.force_authenticate(librarian)
            response = client.post(
                "/api/issues/",
                {"reader_id": reader.id, "copy_id": self.copy.id},
                format="json",
            )
            results.append(response.status_code)

        thread1 = Thread(target=worker, args=(self.librarian, self.reader))
        thread2 = Thread(target=worker, args=(self.librarian, self.other_reader))
        thread1.start()
        thread2.start()
        thread1.join()
        thread2.join()

        self.assertEqual(sorted(results), [status.HTTP_201_CREATED, status.HTTP_409_CONFLICT])
        self.copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.ISSUED)


class QueueBehaviorTests(LibraryTestCase):
    """Регрессионные тесты очереди и бронирования."""

    def _make_copy_unavailable(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])

    def _reservation(self, reader, status, copy=None, offset=0):
        now = timezone.now() + timedelta(seconds=offset)
        return models.Reservation.objects.create(
            reader=reader,
            book=self.book,
            status=status,
            copy=copy,
            queue_date=now,
            expires_at=now + timedelta(hours=48),
            active_slot=1 if status in (
                models.Reservation.Status.PENDING,
                models.Reservation.Status.ACTIVE,
            ) else None,
        )

    def test_queue_list_reader_sees_only_own_position_and_total(self):
        self._make_copy_unavailable()
        self._reservation(self.reader, models.Reservation.Status.PENDING)
        self._reservation(self.other_reader, models.Reservation.Status.PENDING, offset=1)

        self.client.force_authenticate(self.reader)
        response = self.client.get(f"/api/books/{self.book.id}/queue/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["position"], 1)
        self.assertEqual(response.data["total"], 2)
        self.assertNotIn("reader2@test.local", str(response.data))

        self.client.force_authenticate(self.librarian)
        staff_response = self.client.get(f"/api/books/{self.book.id}/queue/")
        self.assertEqual(staff_response.status_code, status.HTTP_200_OK)
        self.assertEqual(staff_response.data["total"], 2)
        self.assertEqual([row["position"] for row in staff_response.data["results"]], [1, 2])

    def test_staff_reservations_waiting_list_includes_position(self):
        self._make_copy_unavailable()
        self._reservation(self.reader, models.Reservation.Status.ACTIVE, copy=self.copy)
        self._reservation(self.other_reader, models.Reservation.Status.PENDING, offset=1)

        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/reservations/", {"status": "ACTIVE"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]), 1)
        self.assertEqual(response.data["results"][0]["status"], models.Reservation.Status.ACTIVE)
        self.assertEqual(response.data["results"][0]["position"], 1)
        self.assertEqual(response.data["results"][0]["book"]["title"], self.book.title)
        self.assertEqual(response.data["results"][0]["copy"]["inventory_number"], "INV-1")
        self.assertEqual(
            response.data["results"][0]["reader"]["full_name"],
            self.reader.full_name,
        )

    def test_me_reservations_returns_own_reservation_with_position(self):
        self._make_copy_unavailable()
        self._reservation(self.reader, models.Reservation.Status.PENDING)

        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/auth/me/reservations/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["book"]["title"], self.book.title)
        self.assertEqual(response.data[0]["position"], 1)
        self.assertIsNotNone(response.data[0]["expires_at"])

    def test_join_queue_missing_book_returns_404(self):
        self._make_copy_unavailable()
        self.client.force_authenticate(self.reader)
        response = self.client.post(
            "/api/books/9999/queue/", {"reader_id": self.reader.id}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_join_queue_with_available_copy_returns_409(self):
        self.client.force_authenticate(self.reader)
        response = self.client.post(
            f"/api/books/{self.book.id}/queue/", {"reader_id": self.reader.id}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        self.assertIn("свободн", response.data["detail"].lower())
        self.assertEqual(models.Reservation.objects.count(), 0)

    def test_join_cancel_cycle_can_repeat_five_times(self):
        self._make_copy_unavailable()
        self.client.force_authenticate(self.reader)
        for _ in range(5):
            join = self.client.post(
                f"/api/books/{self.book.id}/queue/", {"reader_id": self.reader.id}, format="json"
            )
            self.assertEqual(join.status_code, status.HTTP_201_CREATED)
            cancel = self.client.post(
                f"/api/reservations/{join.data['id']}/cancel/", {}, format="json"
            )
            self.assertEqual(cancel.status_code, status.HTTP_200_OK)
        self.assertEqual(
            models.Reservation.objects.filter(status=models.Reservation.Status.CANCELLED).count(),
            5,
        )

    def test_return_reserves_copy_for_first_in_queue_then_fulfils(self):
        holder = models.Reader.objects.create_user(
            email="holder@test.local", password="HolderPass123", full_name="Держатель"
        )
        holder.groups.add(_ensure_group(roles.READER_ROLE))
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=holder,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        first = self._reservation(self.reader, models.Reservation.Status.PENDING)
        second = self._reservation(self.other_reader, models.Reservation.Status.PENDING, offset=1)

        self.client.force_authenticate(self.librarian)
        returned = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(returned.status_code, status.HTTP_200_OK)

        self.copy.refresh_from_db()
        first.refresh_from_db()
        second.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.RESERVED)
        self.assertEqual(first.status, models.Reservation.Status.ACTIVE)
        self.assertEqual(first.copy_id, self.copy.id)
        self.assertEqual(second.status, models.Reservation.Status.PENDING)

        denied = self.client.post(
            "/api/issues/",
            {"reader_id": self.other_reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(denied.status_code, status.HTTP_409_CONFLICT)

        granted = self.client.post(
            "/api/issues/",
            {"reader_id": self.reader.id, "copy_id": self.copy.id},
            format="json",
        )
        self.assertEqual(granted.status_code, status.HTTP_201_CREATED)
        first.refresh_from_db()
        self.copy.refresh_from_db()
        self.assertEqual(first.status, models.Reservation.Status.FULFILLED)
        self.assertIsNone(first.active_slot)
        self.assertEqual(self.copy.status, models.BookCopy.Status.ISSUED)

    def test_cancel_active_reservation_frees_only_its_own_copy(self):
        other_copy = models.BookCopy.objects.create(
            book=self.book, inventory_number="INV-2", status=models.BookCopy.Status.RESERVED
        )
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        reservation = self._reservation(
            self.reader, models.Reservation.Status.ACTIVE, copy=self.copy
        )

        self.client.force_authenticate(self.reader)
        response = self.client.post(
            f"/api/reservations/{reservation.id}/cancel/", {}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.copy.refresh_from_db()
        other_copy.refresh_from_db()
        self.assertEqual(self.copy.status, models.BookCopy.Status.AVAILABLE)
        self.assertEqual(other_copy.status, models.BookCopy.Status.RESERVED)

    def test_cancelling_foreign_reservation_returns_403(self):
        reservation = self._reservation(self.reader, models.Reservation.Status.PENDING)
        self.client.force_authenticate(self.other_reader)
        response = self.client.post(
            f"/api/reservations/{reservation.id}/cancel/", {}, format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        detail = self.client.get(f"/api/reservations/{reservation.id}/")
        self.assertEqual(detail.status_code, status.HTTP_403_FORBIDDEN)

    def test_integrity_error_handler_returns_409(self):
        from django.db import IntegrityError

        from config.exceptions import api_exception_handler

        response = api_exception_handler(IntegrityError("duplicate"), {})
        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)


class QueueConcurrencyTests(TransactionTestCase):
    """Параллельное вступление в очередь на одного читателя."""

    def setUp(self):
        super().setUp()
        self.librarian_group = _ensure_group(roles.LIBRARIAN_ROLE)
        self.reader_group = _ensure_group(roles.READER_ROLE)
        self.reader = models.Reader.objects.create_user(
            email="reader@test.local", password="ReaderPass123", full_name="Читатель Читалов"
        )
        self.reader.groups.add(self.reader_group)
        self.book = models.Book.objects.create(
            title="Тестовая книга", isbn="978-5-000-000-00-0"
        )
        self.copy = models.BookCopy.objects.create(
            book=self.book,
            inventory_number="INV-1",
            status=models.BookCopy.Status.ISSUED,
        )

    def test_ten_parallel_joins_give_one_created_and_nine_conflicts(self):
        import threading

        from rest_framework.test import APIClient

        barrier = threading.Barrier(10)
        results = []

        def worker():
            client = APIClient()
            client.force_authenticate(self.reader)
            barrier.wait()
            response = client.post(
                f"/api/books/{self.book.id}/queue/",
                {"reader_id": self.reader.id},
                format="json",
            )
            results.append(response.status_code)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self.assertEqual(results.count(status.HTTP_201_CREATED), 1, results)
        self.assertEqual(results.count(status.HTTP_409_CONFLICT), 9, results)
        self.assertEqual(models.Reservation.objects.count(), 1)


class ReservationExpiryTests(LibraryTestCase):
    """Истечение просроченных резервов и системные действия в журнале."""

    def setUp(self):
        super().setUp()
        self.now = timezone.now()
        self.past = self.now - timedelta(hours=1)

    def _expired_reservation(self, reader, copy, offset=0):
        return models.Reservation.objects.create(
            reader=reader,
            book=self.book,
            copy=copy,
            status=models.Reservation.Status.ACTIVE,
            active_slot=1,
            queue_date=self.now - timedelta(hours=2) + timedelta(seconds=offset),
            expires_at=self.past,
        )

    def _pending_reservation(self, reader, offset=0):
        return models.Reservation.objects.create(
            reader=reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            active_slot=1,
            queue_date=self.now - timedelta(hours=1) + timedelta(seconds=offset),
            expires_at=self.now + timedelta(hours=1),
        )

    @patch("django.utils.timezone.now")
    def test_expired_reservation_is_replaced_by_next_in_queue(self, mock_now):
        mock_now.return_value = self.now
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        expired = self._expired_reservation(self.reader, self.copy)
        waiting = self._pending_reservation(self.other_reader)

        processed = services.expire_reservations(self.book.id)

        self.assertEqual(len(processed), 1)
        expired.refresh_from_db()
        waiting.refresh_from_db()
        self.copy.refresh_from_db()
        self.assertEqual(expired.status, models.Reservation.Status.EXPIRED)
        self.assertIsNone(expired.active_slot)
        self.assertEqual(waiting.status, models.Reservation.Status.ACTIVE)
        self.assertEqual(waiting.copy_id, self.copy.id)
        self.assertEqual(self.copy.status, models.BookCopy.Status.RESERVED)
        log = models.ActionLog.objects.get(action="reservation.expire")
        self.assertIsNone(log.user)
        self.assertEqual(log.details["reservation_id"], expired.id)

    @patch("django.utils.timezone.now")
    def test_chain_of_three_expired_reservations_processed_in_one_call(self, mock_now):
        mock_now.return_value = self.now
        copies = [self.copy] + [
            models.BookCopy.objects.create(
                book=self.book,
                inventory_number=f"INV-{index}",
                status=models.BookCopy.Status.RESERVED,
            )
            for index in (2, 3)
        ]
        readers = [self.reader, self.other_reader]
        for index in (3, 4):
            readers.append(
                models.Reader.objects.create_user(
                    email=f"reader{index}@test.local",
                    password="ReaderPass123",
                    full_name=f"Читатель {index}",
                )
            )
        expired = [
            self._expired_reservation(reader, copy, offset=index)
            for index, (reader, copy) in enumerate(zip(readers[:3], copies))
        ]
        waiting = self._pending_reservation(readers[3], offset=10)

        processed = services.expire_reservations(self.book.id)

        self.assertEqual(len(processed), 3)
        for reservation in expired:
            reservation.refresh_from_db()
            self.assertEqual(reservation.status, models.Reservation.Status.EXPIRED)
        waiting.refresh_from_db()
        self.assertEqual(waiting.status, models.Reservation.Status.ACTIVE)
        self.assertEqual(
            models.ActionLog.objects.filter(action="reservation.expire").count(),
            3,
        )

    @patch("django.utils.timezone.now")
    def test_issue_copy_on_expired_reservation_returns_409(self, mock_now):
        mock_now.return_value = self.now
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        self._expired_reservation(self.reader, self.copy)
        self.client.force_authenticate(self.librarian)

        response = self.client.post(
            "/api/issues/",
            {"reader_id": self.reader.id, "copy_id": self.copy.id},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_409_CONFLICT)
        self.assertEqual(models.Issue.objects.count(), 0)

    @patch("django.utils.timezone.now")
    def test_repeated_expiration_is_idempotent(self, mock_now):
        mock_now.return_value = self.now
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        expired = self._expired_reservation(self.reader, self.copy)
        waiting = self._pending_reservation(self.other_reader)

        first = services.expire_reservations(self.book.id)
        self.assertEqual(len(first), 1)
        log_count = models.ActionLog.objects.count()
        second = services.expire_reservations(self.book.id)

        self.assertEqual(second, [])
        self.assertEqual(models.ActionLog.objects.count(), log_count)
        expired.refresh_from_db()
        waiting.refresh_from_db()
        self.assertEqual(expired.status, models.Reservation.Status.EXPIRED)
        self.assertEqual(waiting.status, models.Reservation.Status.ACTIVE)

    @patch("django.utils.timezone.now")
    def test_book_detail_and_copies_list_expire_lazily(self, mock_now):
        mock_now.return_value = self.now
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        expired = self._expired_reservation(self.reader, self.copy)
        waiting = self._pending_reservation(self.other_reader)

        detail = self.client.get(f"/api/books/{self.book.id}/")
        self.assertEqual(detail.status_code, status.HTTP_200_OK)
        expired.refresh_from_db()
        waiting.refresh_from_db()
        self.assertEqual(expired.status, models.Reservation.Status.EXPIRED)
        self.assertEqual(waiting.status, models.Reservation.Status.ACTIVE)

        copies = self.client.get(f"/api/books/{self.book.id}/copies/")
        self.assertEqual(copies.status_code, status.HTTP_200_OK)
        self.assertEqual(
            models.ActionLog.objects.filter(action="reservation.expire").count(),
            1,
        )

    @patch("django.utils.timezone.now")
    def test_join_queue_triggers_expiration(self, mock_now):
        mock_now.return_value = self.now
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        expired = self._expired_reservation(self.reader, self.copy)

        with self.assertRaises(services.Conflict):
            services.join_queue(self.other_reader.id, self.book.id)

        expired.refresh_from_db()
        self.assertEqual(expired.status, models.Reservation.Status.EXPIRED)
        self.assertEqual(
            models.ActionLog.objects.filter(action="reservation.expire").count(),
            1,
        )


class StatusTransitionTests(LibraryTestCase):
    """Единая карта переходов статусов и журнал с old_status/new_status."""

    inventory_counter = 0

    def _make_issue(self, status, due_at=None, returned_at=None):
        StatusTransitionTests.inventory_counter += 1
        copy = models.BookCopy.objects.create(
            book=self.book,
            inventory_number=f"TRANS-{StatusTransitionTests.inventory_counter}",
            status=models.BookCopy.Status.ISSUED,
        )
        return models.Issue.objects.create(
            reader=self.reader,
            copy=copy,
            issued_at=timezone.now() - timedelta(days=30),
            due_at=due_at or timezone.now() + timedelta(days=14),
            returned_at=returned_at,
            status=status,
        )

    def _make_reservation(self, status):
        return models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            status=status,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(hours=48),
            active_slot=None,
        )

    def _make_copy(self, status):
        StatusTransitionTests.inventory_counter += 1
        return models.BookCopy.objects.create(
            book=self.book,
            inventory_number=f"TRANS-{StatusTransitionTests.inventory_counter}",
            status=status,
        )

    def _assert_matrix(self, model, enum, transition_map, factory, entity_type):
        for old_status in [item.value for item in enum]:
            for new_status in [item.value for item in enum]:
                with self.subTest(model=entity_type, old=old_status, new=new_status):
                    obj = factory(old_status)
                    logs_before = models.ActionLog.objects.count()
                    allowed = new_status in transition_map[old_status]

                    if allowed:
                        services.change_status(obj, new_status, user=self.librarian)
                        obj.refresh_from_db()
                        self.assertEqual(obj.status, new_status)
                        log = models.ActionLog.objects.get(
                            entity_type=entity_type, entity_id=obj.id
                        )
                        self.assertEqual(log.old_status, old_status)
                        self.assertEqual(log.new_status, new_status)
                        self.assertEqual(log.user, self.librarian)
                    else:
                        with self.assertRaises(services.Conflict) as ctx:
                            services.change_status(obj, new_status, user=self.librarian)
                        detail = str(ctx.exception.detail)
                        self.assertIn("из", detail)
                        self.assertIn("нельзя", detail)
                        obj.refresh_from_db()
                        self.assertEqual(obj.status, old_status)
                        self.assertEqual(models.ActionLog.objects.count(), logs_before)

    def test_issue_transition_matrix(self):
        from library import transitions

        self._assert_matrix(
            models.Issue,
            models.Issue.Status,
            transitions.ISSUE_TRANSITIONS,
            self._make_issue,
            "Issue",
        )

    def test_reservation_transition_matrix(self):
        from library import transitions

        self._assert_matrix(
            models.Reservation,
            models.Reservation.Status,
            transitions.RESERVATION_TRANSITIONS,
            self._make_reservation,
            "Reservation",
        )

    def test_copy_transition_matrix(self):
        from library import transitions

        self._assert_matrix(
            models.BookCopy,
            models.BookCopy.Status,
            transitions.BOOK_COPY_TRANSITIONS,
            self._make_copy,
            "BookCopy",
        )

    def test_status_and_log_roll_back_together(self):
        issue = self._make_issue(models.Issue.Status.ISSUED)
        with self.assertRaises(RuntimeError):
            with transaction.atomic():
                services.change_status(
                    issue, models.Issue.Status.RETURNED, user=self.librarian
                )
                raise RuntimeError("failure after status change")
        issue.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.ISSUED)
        self.assertEqual(models.ActionLog.objects.count(), 0)

    def test_reader_cannot_return_issue(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.reader)
        response = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        issue.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.ISSUED)

    def test_mark_overdue_sets_status_and_logs_transition(self):
        overdue = self._make_issue(
            models.Issue.Status.ISSUED, due_at=timezone.now() - timedelta(days=1)
        )
        fresh = self._make_issue(
            models.Issue.Status.ISSUED, due_at=timezone.now() + timedelta(days=1)
        )

        processed = services.mark_overdue()

        self.assertEqual([item.id for item in processed], [overdue.id])
        overdue.refresh_from_db()
        fresh.refresh_from_db()
        self.assertEqual(overdue.status, models.Issue.Status.OVERDUE)
        self.assertEqual(fresh.status, models.Issue.Status.ISSUED)
        log = models.ActionLog.objects.get(entity_type="Issue", entity_id=overdue.id)
        self.assertEqual(log.old_status, models.Issue.Status.ISSUED)
        self.assertEqual(log.new_status, models.Issue.Status.OVERDUE)

    def test_issue_list_triggers_mark_overdue(self):
        issue = self._make_issue(
            models.Issue.Status.ISSUED, due_at=timezone.now() - timedelta(days=1)
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/issues/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        issue.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.OVERDUE)

    def test_return_overdue_issue_is_allowed(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now() - timedelta(days=30),
            due_at=timezone.now() - timedelta(days=1),
            status=models.Issue.Status.OVERDUE,
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.post(f"/api/issues/{issue.id}/return/", {}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        issue.refresh_from_db()
        self.copy.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.RETURNED)
        self.assertEqual(self.copy.status, models.BookCopy.Status.AVAILABLE)

    def test_mark_lost_endpoint_marks_issue_and_copy(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.librarian)
        response = self.client.post(f"/api/issues/{issue.id}/mark-lost/", {}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        issue.refresh_from_db()
        self.copy.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.LOST)
        self.assertEqual(self.copy.status, models.BookCopy.Status.LOST)
        issue_log = models.ActionLog.objects.get(entity_type="Issue", entity_id=issue.id)
        copy_log = models.ActionLog.objects.get(entity_type="BookCopy", entity_id=self.copy.id)
        self.assertEqual(
            (issue_log.old_status, issue_log.new_status),
            (models.Issue.Status.ISSUED, models.Issue.Status.LOST),
        )
        self.assertEqual(
            (copy_log.old_status, copy_log.new_status),
            (models.BookCopy.Status.ISSUED, models.BookCopy.Status.LOST),
        )

    def test_reader_cannot_mark_issue_lost(self):
        self.copy.status = models.BookCopy.Status.ISSUED
        self.copy.save(update_fields=["status"])
        issue = models.Issue.objects.create(
            reader=self.reader,
            copy=self.copy,
            issued_at=timezone.now(),
            due_at=timezone.now() + timedelta(days=14),
            status=models.Issue.Status.ISSUED,
        )
        self.client.force_authenticate(self.reader)
        response = self.client.post(f"/api/issues/{issue.id}/mark-lost/", {}, format="json")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        issue.refresh_from_db()
        self.assertEqual(issue.status, models.Issue.Status.ISSUED)

    def test_fulfilled_and_expired_transitions_write_status_logs(self):
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        active = models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            copy=self.copy,
            status=models.Reservation.Status.ACTIVE,
            active_slot=1,
            queue_date=timezone.now() - timedelta(hours=2),
            expires_at=timezone.now() + timedelta(hours=1),
        )
        services.issue_copy(self.reader.id, self.copy.id, user=self.librarian)
        active.refresh_from_db()
        self.assertEqual(active.status, models.Reservation.Status.FULFILLED)
        fulfilled_log = models.ActionLog.objects.get(
            entity_type="Reservation", entity_id=active.id
        )
        self.assertEqual(fulfilled_log.old_status, models.Reservation.Status.ACTIVE)
        self.assertEqual(fulfilled_log.new_status, models.Reservation.Status.FULFILLED)

        expired = models.Reservation.objects.create(
            reader=self.other_reader,
            book=self.book,
            copy=self.copy,
            status=models.Reservation.Status.ACTIVE,
            active_slot=None,
            queue_date=timezone.now() - timedelta(hours=3),
            expires_at=timezone.now() - timedelta(hours=1),
        )
        services.mark_overdue()
        services.expire_reservations(self.book.id)
        expired.refresh_from_db()
        self.assertEqual(expired.status, models.Reservation.Status.EXPIRED)
        expired_log = models.ActionLog.objects.get(
            entity_type="Reservation", entity_id=expired.id
        )
        self.assertEqual(expired_log.old_status, models.Reservation.Status.ACTIVE)
        self.assertEqual(expired_log.new_status, models.Reservation.Status.EXPIRED)


class CancellationTimestampTests(LibraryTestCase):
    """Момент отмены брони фиксируется в cancelled_at."""

    def _reservation(self, status):
        return models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            status=status,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(hours=48),
            active_slot=None,
        )

    def test_change_status_sets_cancelled_at(self):
        reservation = self._reservation(models.Reservation.Status.PENDING)
        before = timezone.now()
        services.change_status(
            reservation, models.Reservation.Status.CANCELLED, user=self.librarian
        )
        reservation.refresh_from_db()
        self.assertIsNotNone(reservation.cancelled_at)
        self.assertGreaterEqual(reservation.cancelled_at, before)

    def test_other_transitions_leave_cancelled_at_empty(self):
        reservation = self._reservation(models.Reservation.Status.ACTIVE)
        services.change_status(
            reservation, models.Reservation.Status.FULFILLED, user=self.librarian
        )
        reservation.refresh_from_db()
        self.assertIsNone(reservation.cancelled_at)

    def test_cancel_service_sets_cancelled_at(self):
        reservation = self._reservation(models.Reservation.Status.PENDING)
        services.cancel_reservation(reservation.id, user=self.reader)
        reservation.refresh_from_db()
        self.assertEqual(reservation.status, models.Reservation.Status.CANCELLED)
        self.assertIsNotNone(reservation.cancelled_at)


class ActionLogApiTests(LibraryTestCase):
    """Эндпоинт журнала действий: права, фильтры, формат и N+1."""

    def _log(self, **kwargs):
        defaults = {
            "user": self.librarian,
            "action": "issue.status_change",
            "entity_type": "Issue",
            "entity_id": 1,
            "old_status": models.Issue.Status.ISSUED,
            "new_status": models.Issue.Status.RETURNED,
            "details": {},
        }
        defaults.update(kwargs)
        return models.ActionLog.objects.create(**defaults)

    def test_reader_is_forbidden(self):
        self.client.force_authenticate(self.reader)
        response = self.client.get("/api/action-log/")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_staff_can_read_paginated_list_sorted_by_created_at(self):
        logs = [self._log(entity_id=i) for i in range(3)]
        for offset, log in enumerate(logs):
            models.ActionLog.objects.filter(pk=log.pk).update(
                created_at=timezone.now() + timedelta(minutes=offset)
            )
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/action-log/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 3)
        self.assertEqual(
            [row["id"] for row in response.data["results"]],
            [log.id for log in reversed(logs)],
        )

    def test_filters(self):
        first = self._log(
            user=self.librarian,
            action="issue.create",
            entity_type="Issue",
            entity_id=10,
        )
        second = self._log(
            user=self.admin,
            action="queue.join",
            entity_type="Reservation",
            entity_id=20,
        )
        self.client.force_authenticate(self.librarian)
        cases = [
            ({"user": self.librarian.id}, [first.id]),
            ({"entity_type": "Reservation"}, [second.id]),
            ({"entity_id": 20}, [second.id]),
            ({"action": "issue.create"}, [first.id]),
        ]
        for params, expected in cases:
            with self.subTest(params=params):
                response = self.client.get("/api/action-log/", params)
                self.assertEqual(response.status_code, status.HTTP_200_OK)
                self.assertEqual([row["id"] for row in response.data["results"]], expected)

        models.ActionLog.objects.filter(pk=first.pk).update(
            created_at=timezone.now() - timedelta(days=10)
        )
        yesterday = (timezone.now() - timedelta(days=1)).date().isoformat()
        old_date = (timezone.now() - timedelta(days=10)).date().isoformat()
        response = self.client.get("/api/action-log/", {"date_from": yesterday})
        self.assertEqual([row["id"] for row in response.data["results"]], [second.id])
        response = self.client.get("/api/action-log/", {"date_to": old_date})
        self.assertEqual([row["id"] for row in response.data["results"]], [first.id])

    def test_invalid_filters_return_400(self):
        self.client.force_authenticate(self.librarian)
        for params in [
            {"date_from": "not-a-date"},
            {"date_to": "2026-99-99"},
            {"user": "abc"},
            {"entity_id": "abc"},
        ]:
            with self.subTest(params=params):
                response = self.client.get("/api/action-log/", params)
                self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_serializer_shape_and_system_user(self):
        system = self._log(user=None, details={"reason": "cron"})
        user_log = self._log(user=self.librarian, entity_id=2)
        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/action-log/")
        rows = {row["id"]: row for row in response.data["results"]}

        self.assertEqual(
            set(rows[system.id].keys()),
            {
                "id",
                "user",
                "action",
                "entity_type",
                "entity_id",
                "old_status",
                "new_status",
                "created_at",
                "details",
            },
        )
        self.assertIsNone(rows[system.id]["user"])
        self.assertEqual(rows[system.id]["details"], {"reason": "cron"})
        self.assertEqual(
            rows[user_log.id]["user"],
            {
                "id": self.librarian.id,
                "full_name": self.librarian.full_name,
                "email": self.librarian.email,
            },
        )

    def test_logs_after_issue_return_and_cancel(self):
        self.copy.status = models.BookCopy.Status.RESERVED
        self.copy.save(update_fields=["status"])
        active = models.Reservation.objects.create(
            reader=self.reader,
            book=self.book,
            copy=self.copy,
            status=models.Reservation.Status.ACTIVE,
            active_slot=1,
            queue_date=timezone.now() - timedelta(hours=2),
            expires_at=timezone.now() + timedelta(hours=1),
        )
        issue = services.issue_copy(self.reader.id, self.copy.id, user=self.librarian)
        services.return_issue(issue.id, user=self.librarian)
        waiting = models.Reservation.objects.create(
            reader=self.other_reader,
            book=self.book,
            status=models.Reservation.Status.PENDING,
            active_slot=1,
            queue_date=timezone.now(),
            expires_at=timezone.now() + timedelta(hours=48),
        )
        services.cancel_reservation(waiting.id, user=self.other_reader)

        self.client.force_authenticate(self.librarian)
        response = self.client.get("/api/action-log/")
        rows = {
            (row["entity_type"], row["entity_id"], row["old_status"], row["new_status"])
            for row in response.data["results"]
        }
        self.assertIn(
            (
                "Reservation",
                active.id,
                models.Reservation.Status.ACTIVE,
                models.Reservation.Status.FULFILLED,
            ),
            rows,
        )
        self.assertIn(
            (
                "Issue",
                issue.id,
                models.Issue.Status.ISSUED,
                models.Issue.Status.RETURNED,
            ),
            rows,
        )
        self.assertIn(
            (
                "Reservation",
                waiting.id,
                models.Reservation.Status.PENDING,
                models.Reservation.Status.CANCELLED,
            ),
            rows,
        )

    def test_no_n_plus_1_queries(self):
        for index in range(5):
            self._log(user=self.librarian, entity_id=index)
        self.client.force_authenticate(self.librarian)
        # Проверка роли + COUNT + SELECT с JOIN пользователя; без запросов на строку.
        with self.assertNumQueries(3):
            self.client.get("/api/action-log/")


class LoadDemoDataTests(TransactionTestCase):
    """Тесты management command load_demo_data."""

    def setUp(self):
        self.librarian_group = _ensure_group(roles.LIBRARIAN_ROLE)
        self.reader_group = _ensure_group(roles.READER_ROLE)
        self.admin_group = _ensure_group(roles.ADMIN_ROLE)

    def _load_demo_data(self):
        from django.core.management import call_command

        call_command("load_demo_data")

    # ---------- Базовая загрузка демо-набора ----------

    def test_demo_data_loads_catalog_with_covers(self):
        self._load_demo_data()
        self.assertEqual(models.Book.objects.count(), 24)
        self.assertEqual(models.Genre.objects.count(), 8)
        self.assertGreaterEqual(models.Author.objects.count(), 8)
        self.assertEqual(models.Book.objects.filter(cover_url__isnull=False).count(), 24)

    def test_demo_data_books_have_authors_and_genres(self):
        self._load_demo_data()
        for book in models.Book.objects.all():
            self.assertGreaterEqual(book.authors.count(), 1)
            self.assertLessEqual(book.authors.count(), 3)
            self.assertGreaterEqual(book.genres.count(), 1)
            self.assertLessEqual(book.genres.count(), 2)
            self.assertGreaterEqual(book.copies.count(), 1)
            self.assertLessEqual(book.copies.count(), 4)

    def test_demo_data_creates_issues_with_all_statuses(self):
        self._load_demo_data()
        issues = models.Issue.objects.all()
        self.assertGreaterEqual(issues.count(), 30)
        for status_value in (
            models.Issue.Status.RETURNED,
            models.Issue.Status.ISSUED,
            models.Issue.Status.OVERDUE,
            models.Issue.Status.LOST,
        ):
            self.assertTrue(issues.filter(status=status_value).exists())

    def test_demo_data_users_and_blocked_reader(self):
        self._load_demo_data()
        self.assertTrue(models.Reader.objects.filter(email="admin@library.local").exists())
        self.assertTrue(models.Reader.objects.filter(email="librarian@library.local").exists())
        for index in range(8):
            self.assertTrue(models.Reader.objects.filter(email=f"reader{index}@library.local").exists())
        blocked = models.Reader.objects.filter(email="reader7@library.local").first()
        self.assertEqual(blocked.status, models.Reader.Status.BLOCKED)

    # ---------- Идемпотентность ----------

    def test_demo_data_rerun_does_not_duplicate(self):
        self._load_demo_data()
        before = {
            "books": models.Book.objects.count(),
            "copies": models.BookCopy.objects.count(),
            "issues": models.Issue.objects.count(),
            "reservations": models.Reservation.objects.count(),
            "authors": models.Author.objects.count(),
            "genres": models.Genre.objects.count(),
            "readers": models.Reader.objects.count(),
        }
        self._load_demo_data()
        after = {
            "books": models.Book.objects.count(),
            "copies": models.BookCopy.objects.count(),
            "issues": models.Issue.objects.count(),
            "reservations": models.Reservation.objects.count(),
            "authors": models.Author.objects.count(),
            "genres": models.Genre.objects.count(),
            "readers": models.Reader.objects.count(),
        }
        self.assertEqual(before, after)

    # ---------- Инварианты консистентности ----------

    def test_demo_data_issued_copies_match_open_issues(self):
        self._load_demo_data()
        issued_copies = models.BookCopy.objects.filter(status=models.BookCopy.Status.ISSUED).count()
        open_issues = models.Issue.objects.filter(
            status__in=[models.Issue.Status.ISSUED, models.Issue.Status.OVERDUE],
        ).count()
        self.assertEqual(issued_copies, open_issues)

    def test_demo_data_reserved_copy_has_active_reservation(self):
        self._load_demo_data()
        reserved_copies = models.BookCopy.objects.filter(status=models.BookCopy.Status.RESERVED)
        self.assertTrue(reserved_copies.exists())
        for copy in reserved_copies:
            self.assertTrue(
                models.Reservation.objects.filter(
                    copy=copy,
                    status=models.Reservation.Status.ACTIVE,
                    active_slot=1,
                ).exists(),
            )

    # ---------- Сценарий очереди ----------

    def test_demo_data_queue_scenario(self):
        self._load_demo_data()
        book = models.Book.objects.get(title="451 градус по Фаренгейту")
        self.assertEqual(book.copies.count(), 2)
        self.assertEqual(
            book.copies.filter(status=models.BookCopy.Status.ISSUED).count(),
            book.copies.count(),
        )
        queue_reservations = models.Reservation.objects.filter(
            book=book,
            status=models.Reservation.Status.PENDING,
        )
        self.assertEqual(queue_reservations.count(), 3)

        reserved_book = models.Book.objects.get(title="Мастер и Маргарита")
        reserved_copies = reserved_book.copies.filter(status=models.BookCopy.Status.RESERVED)
        self.assertEqual(reserved_copies.count(), 1)
        reservation = models.Reservation.objects.filter(
            book=reserved_book,
            status=models.Reservation.Status.ACTIVE,
            copy__isnull=False,
        )
        self.assertEqual(reservation.count(), 1)
        self.assertEqual(reservation.first().reader.email, "reader0@library.local")

    def test_demo_data_reset_clears_and_reloads(self):
        self._load_demo_data()
        models.BookCopy.objects.create(
            book=models.Book.objects.first(),
            inventory_number="STRAY-COPY-1",
            status=models.BookCopy.Status.AVAILABLE,
        )
        from django.core.management import call_command

        call_command("load_demo_data", reset=True)
        self.assertEqual(models.BookCopy.objects.filter(inventory_number="STRAY-COPY-1").count(), 0)
        self.assertEqual(models.Book.objects.count(), 24)

    def test_demo_data_cancelled_and_expired_reservations_dates(self):
        from django.core.management import call_command

        call_command("load_demo_data")
        cancelled = models.Reservation.objects.filter(status=models.Reservation.Status.CANCELLED).first()
        self.assertIsNotNone(cancelled)
        self.assertNotEqual(cancelled.cancelled_at, None)
        self.assertGreater(
            timezone.now() - cancelled.cancelled_at,
            timedelta(days=20),
        )
        expired = models.Reservation.objects.filter(status=models.Reservation.Status.EXPIRED).first()
        self.assertIsNotNone(expired)
        self.assertNotEqual(expired.expires_at, None)
        self.assertLess(expired.expires_at, timezone.now())
